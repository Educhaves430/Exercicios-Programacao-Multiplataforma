﻿namespace WPFApp9
{
    public delegate void voidArgInt(int value);
}