﻿namespace WPFAppB
{
    public delegate void voidNoArgs();
}