﻿namespace WPFAppA
{
    public delegate void voidNoArgs();
}